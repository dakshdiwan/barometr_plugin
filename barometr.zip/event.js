// // This function is called onload in the popup code
// function getPageDetails(callback) {
//     // Inject the content script into the current page
//     chrome.tabs.executeScript(null, { file: 'content.js' });
//     // Perform the callback when a message is received from the content script
//     chrome.runtime.onMessage.addListener(function(message)  {
//         // Call the callback function
//         callback(message);
//     });
// };
//
// var xhr = new XMLHttpRequest();
// xhr.open("POST", "http://ec2-52-91-18-68.compute-1.amazonaws.com/test.py", true);
// xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
// xhr.send("text=TestText");
// xhr.onreadystatechange = function(data) {
//   if (xhr.readyState == 4) {
//     console.log("GET WENT THROUGH");
//     console.log(data);
//   }
// }
// xhr.send();
//
// chrome.runtime.onMessage.addListener(function (msg, sender) {
//   // Validate message structure
//   if(( msg.from === 'content') && (msg.subject === 'showPageAction')){
//     //Enable page-action for requesting tab
//     chrome.browserAction.show(sender.tab.id);
//   }
// });
