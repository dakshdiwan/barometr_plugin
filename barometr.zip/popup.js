//Update the relevant fields with the data

function setMeters(test){
  $('#test').text(test);
  console.log("It worked");
}

$(document).ready(function(){

console.log("Test popup.js");

chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
 chrome.tabs.sendMessage(tabs[0].id, {greeting: "getText"}, function(response) {
   jQuery.ajax({
       type: "POST",
       url: "http://ec2-52-91-18-68.compute-1.amazonaws.com/test.py",
       data: {text: response.text},
       success: function(data) {
           console.log(data);
           //setMeters(data);
       }
     });
 });
});

});
