#barometr

__barometr__ is a chrome extension that learns the political bias of news sites
